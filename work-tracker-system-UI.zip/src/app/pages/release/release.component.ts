import { Component, OnInit } from '@angular/core';
import { ProjectDetailsService } from 'src/app/shared/service/project-details.service';
import { Project, Release } from 'src/app/shared/models/SprintDetails.model';
import { FormGroup, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ReleaseService } from 'src/app/shared/service/release.service';
import { error } from 'protractor';

@Component({
  selector: 'app-release',
  templateUrl: './release.component.html',
  styleUrls: ['./release.component.scss']
})
export class ReleaseComponent implements OnInit {
  createReleaseGroup: FormGroup;
  viewreleaseGroup: FormGroup;

  constructor(private projectDetailsService: ProjectDetailsService, private datePipe: DatePipe, private releaseService: ReleaseService) {
    this.createReleaseGroup = new FormGroup({
      name: new FormControl(''),
      projectName: new FormControl(''),
      description: new FormControl(''),
      version: new FormControl(''),
      releaseDate: new FormControl('')
    })
    this.viewreleaseGroup = new FormGroup({
      // input: new FormControl(''),
      projectName: new FormControl('')
    })
  }

  ngOnInit() {
    this.getAllProjects();
  }
  projects: Project[];
  getAllProjects() {
    this.projectDetailsService.getProjects().subscribe(data => {
      this.projects = data as Project[];
      console.log('projects: ', this.projects)
    },
      error => {
        console.log('error', error)
      })
  }

  release: Release[] = [];
  createRelease(createReleaseGroup) {
    this.releaseService.createRelease(this.createReleaseGroup.value).subscribe(data => {
      window.alert('created Release plan successfully...');
      this.createReleaseGroup.reset();
    }, error => {
      console.log(error);
    })
  }

  viewrelease(input) {
    console.log('search input: ' + this.viewreleaseGroup.value.input);
  }

  releaseNameSelected = false;
  getRelease(viewreleaseGroup) {
    this.releaseService.getReleaseDetailsByProjectName(this.viewreleaseGroup.value.projectName).subscribe(data => {
      this.releaseNameSelected = true;
      this.release = data as Release[];
    })
  }

}