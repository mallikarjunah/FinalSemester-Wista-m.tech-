import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { GlobalService } from 'src/app/shared/service/global.service';
import { Router } from '@angular/router';
import { UserProfile } from 'src/app/shared/models/SprintDetails.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  userForm: FormGroup;

  loginFailed = false;


  constructor(
    private globalService: GlobalService,
    private router: Router
  ) {
    this.userForm = new FormGroup({
      username: new FormControl('', [Validators.required, Validators.nullValidator]),
      password: new FormControl('', [Validators.required, Validators.nullValidator])
    });
  }

  onSubmit() {
    if (this.userForm.invalid) {
      return;
    }
    this.globalService.login(this.userForm.value).subscribe((data) => {
      console.log(data);
      sessionStorage.setItem('loginDetails', JSON.stringify(data))
      this.router.navigate(['dashboard']);
    }, error => {
      this.loginFailed = true;
    });
  }

  ngOnInit() {

  }
}
