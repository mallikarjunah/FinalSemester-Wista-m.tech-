import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserProfile } from 'src/app/shared/models/SprintDetails.model';
import { GlobalService } from 'src/app/shared/service/global.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  userProfile: UserProfile;

  constructor(private route: Router, private userService: GlobalService) {
    this.userProfile = JSON.parse(sessionStorage.getItem('loginDetails'))

    this.changePasswordForm = new FormGroup({
      emailId: new FormControl(this.userProfile.emailId, [Validators.required]),
      newPassword: new FormControl(''),
      confirmNewPassword: new FormControl('')
    })
  }

  ngOnInit() {
  }

  isConfirmPasswordMatched = true;
  isCurrenPasswordMatch = true;
  changePassword(changePasswordForm) {
    this.isConfirmPasswordMatched = true;
    if (this.changePasswordForm.value.newPassword != this.changePasswordForm.value.confirmNewPassword) {
      this.isConfirmPasswordMatched = false;
    }
    if (this.isConfirmPasswordMatched === true && this.isCurrenPasswordMatch === true) {
      this.userService.changePassword(this.userProfile.userId, this.changePasswordForm.value.newPassword).subscribe(data => {
        window.alert('Password Changed successfully...');
        sessionStorage.removeItem('loginDetails');
        sessionStorage.setItem('loginDetails', JSON.stringify(data));
      })
    }
  }
}
