import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserProfile } from 'src/app/shared/models/SprintDetails.model';
import { GlobalService } from 'src/app/shared/service/global.service';



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  userProfile: UserProfile;

  userProfileForm: FormGroup;
  constructor(private route: Router, private userService: GlobalService) {
    this.userProfile = JSON.parse(sessionStorage.getItem('loginDetails'))
    this.userProfileForm = new FormGroup({
      firstName: new FormControl(this.userProfile.firstName),
      lastName: new FormControl(this.userProfile.lastName),
      userId: new FormControl({ value: this.userProfile.userId, disabled: true }),
      projectName: new FormControl(this.userProfile.projectName),
      userName: new FormControl({ value: this.userProfile.userName, disabled: true }),
      emailId: new FormControl({ value: this.userProfile.emailId, disabled: true }),
      updatedAt: new FormControl({ value: this.userProfile.updatedAt, disabled: true })
    })
  }

  ngOnInit() {

  }

  updateProfile(userProfileForm) {
    this.userService.updateProfile(this.userProfile.userId, this.userProfileForm.value).subscribe(data => {
      sessionStorage.removeItem('loginDetails');
      sessionStorage.setItem('loginDetails', JSON.stringify(data));
      window.alert('Profile updated successfully.')
    }, error => {
      window.alert('updation failed.')
    });
  }

  ok() {
    this.route.navigate(['/dashboard']);
  }
}
