import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IssueService } from 'src/app/shared/service/issue.service';
import { Task } from 'src/app/shared/models/SprintDetails.model';
import { MatDialog } from '@angular/material';
import { DialogBoxComponent } from 'src/app/shared/dialog-box/dialog-box.component';

@Component({
  selector: 'app-search-issue',
  templateUrl: './search-issue.component.html',
  styleUrls: ['./search-issue.component.scss']
})
export class SearchIssueComponent implements OnInit {

  isSearched = false;
  searchIssue: FormGroup;
  issues: Task[];
  formData: string;
  constructor(private issueService: IssueService, public dialog: MatDialog) {
    this.searchIssue = new FormGroup({
      input: new FormControl('', [Validators.required])
    });
  }

  ngOnInit() {
  }

  onSearch() {
    this.issueService.search(this.searchIssue.value.input).subscribe(data => {
      console.log(data);
      this.isSearched = true;
      this.issues = data as Task[];
    }, error => {
      console.log(error)
      this.isSearched = false;
    });
  }


  onDisplay(task) {
    console.log(task);
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '70%',
      data: task,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.formData = { id: task.id, ...result }
      console.log('The dialog was closed', this.formData);
    });
    
  }

}
