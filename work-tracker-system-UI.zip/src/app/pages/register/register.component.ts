import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { FormGroup, Validators, FormControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { UserProfile } from 'src/app/shared/models/SprintDetails.model';
import { GlobalService } from 'src/app/shared/service/global.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerFormGroup: FormGroup;
  passwordMatch = true;
  userProfile: UserProfile;

  constructor(private route: Router, private userService: GlobalService) {
    this.registerFormGroup = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl(''),
      emailId: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
    })
  }

  ngOnInit() {
  }

  createProfile() {
    if (this.registerFormGroup.value.password === this.registerFormGroup.value.confirmPassword) {
      this.userProfile = this.registerFormGroup.value;
      this.userService.register(this.userProfile).subscribe(x => {
        console.log('registered successfully...', x);
        window.alert('registered successfully')
        this.registerFormGroup.reset();
        this.route.navigate(['/login'])
      },
        error => {
          console.log(error);
        });
      console.log(this.userProfile)
      this.passwordMatch = true;
      this.registerFormGroup.reset();
    } else {
      this.registerFormGroup.reset();
      this.passwordMatch = false;
    }
  }

}

