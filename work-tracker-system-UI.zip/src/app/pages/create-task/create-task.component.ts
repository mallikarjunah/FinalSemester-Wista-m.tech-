import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Project, Board, Priority, Task, UserProfile, SprintDetails } from 'src/app/shared/models/SprintDetails.model';
import { BoardService } from 'src/app/shared/service/board.service';
import { ProjectDetailsService } from 'src/app/shared/service/project-details.service';
import { IssueService } from 'src/app/shared/service/issue.service';
import { GlobalService } from 'src/app/shared/service/global.service';
import { SprintDetailsService } from 'src/app/shared/service/sprint-details.service';


@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.scss']
})
export class CreateTaskComponent implements OnInit {

  userProfile: UserProfile;
  issueDetail: Task;
  projects: Project[];
  boards: Board[];
  users: UserProfile[];
  sprintDetails: SprintDetails[] = [];
  issueTypes = ['story', 'bug', 'test', 'task', 'sub task']
  newTask: Task;
  createTaskForm: FormGroup;
  asControl = new FormControl();
  options: string[] = [];
  filteredOptions: Observable<string[]>;

  constructor(
    private router: Router,
    private boardService: BoardService,
    private projectDetailsService: ProjectDetailsService,
    private issueService: IssueService,
    private globalService: GlobalService,
    private sprintService: SprintDetailsService
  ) {
    this.userProfile = JSON.parse(sessionStorage.getItem('loginDetails'));
    this.createTaskForm = new FormGroup({
      summary: new FormControl(''),
      description: new FormControl(''),
      projectName: new FormControl('', [Validators.required]),
      boardName: new FormControl('', [Validators.required]),
      priority: new FormControl('', [Validators.required]),
      linkedBy: new FormControl(''),
      issueType: new FormControl(''),
      assignee: this.asControl,
      estimatedHours: new FormControl(''),
      createdBy: new FormControl(this.userProfile.emailId, [Validators.required]),
      sprintName: new FormControl('')
    });
  }




  ngOnInit() {
    this.getOpenSprintNames();
    this.getAllProjects();
    this.getAllBoardDetails();
    this.globalService.getAllUserDetails().subscribe(data => {
      this.users = data as UserProfile[];
      for (let i = 0; i < this.users.length; i++) {
        this.options.push(this.users[i].emailId);
      }
    })
    this.filteredOptions = this.asControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );

  }

  private _filter(value: string): string[] {
    console.log('value:=' + value)
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  onSubmit() {
    console.log(this.createTaskForm.value);
    this.newTask = this.createTaskForm.value;
    console.log(JSON.stringify(this.newTask));
    this.issueService.createTask(this.newTask).subscribe(data => {
      this.issueDetail = data;
      console.log(this.issueDetail)
      window.alert('created Task with Id: ' + this.issueDetail.id);
    });
  }

  getAllProjects() {
    this.projectDetailsService.getProjects().subscribe(data => {
      this.projects = data as Project[];
      console.log('projects: ', this.projects)
    },
      error => {
        console.log('error', error)
      })
  }

  getAllBoardDetails() {
    this.boardService.getBoards().subscribe(data => {
      this.boards = data as Board[];
      console.log('board: ', this.boards)
    })
  }


  getAllUsers() {
    this.globalService.getAllUserDetails().subscribe(data => {
      this.users = data as UserProfile[];
      for (let i = 0; i < this.users.length; i++) {
        this.options.push(this.users[i].emailId);
      }
    })
  }

  sprintDs: SprintDetails[];
  getOpenSprintNames() {
    this.sprintService.getOpenSprints().subscribe(data => {
      this.sprintDs = data as SprintDetails[];
      for (let i = 0; i < this.sprintDs.length; i++) {
        if (this.sprintDs[i].sprintStatus === 'open' || this.sprintDs[i].sprintStatus === 'ToDo') {
          this.sprintDetails.push(this.sprintDs[i]);
        }
      }
      console.log(this.sprintDetails)
    })
  }


  priorities: Priority[] = [
    { priority: 'Low' },
    { priority: 'Minor' },
    { priority: 'Major' },
    { priority: 'Critical' },
    { priority: 'Blocker' }
  ]

}
