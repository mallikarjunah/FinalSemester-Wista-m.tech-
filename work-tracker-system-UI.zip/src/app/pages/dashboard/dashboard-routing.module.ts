import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardMainComponent } from '../dashboard-main/dashboard-main.component';
import { CurrentSprintComponent } from '../current-sprint/current-sprint.component';
import { ReportsComponent } from '../reports/reports.component';
import { BacklogsComponent } from '../backlogs/backlogs.component';
import { ReleaseComponent } from '../release/release.component';
import { DashboardComponent } from './dashboard.component';
import { SearchIssueComponent } from '../search-issue/search-issue.component';
import { CreateProjectBoardComponent } from '../create-project-board/create-project-board.component';


const routes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent,
    children: [
      { path: '', component: DashboardMainComponent },
      { path: 'current-sprint', component: CurrentSprintComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'backlogs', component: BacklogsComponent },
      { path: 'release', component: ReleaseComponent },
      { path: 'search-issue', component: SearchIssueComponent },
      { path: 'create-pb', component: CreateProjectBoardComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
