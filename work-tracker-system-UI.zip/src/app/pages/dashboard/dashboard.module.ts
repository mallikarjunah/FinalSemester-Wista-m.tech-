import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardMainComponent } from '../dashboard-main/dashboard-main.component';
import { CurrentSprintComponent } from '../current-sprint/current-sprint.component';
import { ReportsComponent } from '../reports/reports.component';
import { BacklogsComponent } from '../backlogs/backlogs.component';
import { ReleaseComponent } from '../release/release.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    DashboardComponent,
    DashboardMainComponent,
    CurrentSprintComponent,
    ReportsComponent,
    BacklogsComponent,
    ReleaseComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,

    SharedModule
  ],

})
export class DashboardModule { }
