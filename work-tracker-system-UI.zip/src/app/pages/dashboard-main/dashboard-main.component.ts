import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { DialogBoxComponent } from 'src/app/shared/dialog-box/dialog-box.component';
import { Task, UserData, UserProfile } from 'src/app/shared/models/SprintDetails.model';
import { IssueService } from 'src/app/shared/service/issue.service';


@Component({
  selector: 'app-dashboard-main',
  templateUrl: './dashboard-main.component.html',
  styleUrls: ['./dashboard-main.component.scss']
})
export class DashboardMainComponent implements OnInit {
  tasks: Task[] = [];
  userProfile: UserProfile;
  priorities = [
    { value: 'Low', color: '#ffeb00', icon: 'arrow_downward' },
    { value: 'Minor', color: '#ffa500', icon: 'arrow_downward' },
    { value: 'Major', color: '#ff7600', icon: 'arrow_upward' },
    { value: 'Critical', color: '#ff3b00', icon: 'arrow_upward' },
    { value: 'Blocker', color: '#ff0000', icon: 'block' }
  ]
  formData: string;
  displayedColumns: string[] = ['id', 'status', 'summary', 'priority'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private router: Router, public dialog: MatDialog, private issueService: IssueService) {
  }

  ngOnInit() {
    this.userProfile = JSON.parse(sessionStorage.getItem('loginDetails'));
    this.issueService.getIssues(this.userProfile.emailId).subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onSearch(task) {
    console.log(task);
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '70%',
      data: task,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.formData = { id: task.id, ...result }
    });
  }
}
