import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Task, SprintDetails } from 'src/app/shared/models/SprintDetails.model';
import { IssueService } from 'src/app/shared/service/issue.service';
import { DialogBoxComponent } from 'src/app/shared/dialog-box/dialog-box.component';
import { MatDialog } from '@angular/material';
import { SprintDetailsService } from 'src/app/shared/service/sprint-details.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-backlogs',
  templateUrl: './backlogs.component.html',
  styleUrls: ['./backlogs.component.scss']
})
export class BacklogsComponent implements OnInit {
  issues: Task[] = [];
  formData: string;
  sprintDetails: String[];
  backlogGroup: FormGroup;
  constructor(private issueService: IssueService,
    public dialog: MatDialog, private sprintService: SprintDetailsService) {
    this.backlogGroup = new FormGroup({
      sprintName: new FormControl('')
    })
  }
  ngOnInit() {
    this.sprintService.getToDoSprint().subscribe(data => {
      this.sprintDetails = data as String[];
    })
    this.issueService.backlogs().subscribe(data => {
      this.issues = data as Task[];
    })
  }

  updateIssue(item) {
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '70%',
      data: item,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.formData = { id: item.id, ...result }
    });
  }

  startSprint(backlogGroup) {
    this.sprintService.openOrCloseSprint(this.backlogGroup.value.sprintName, 'open').subscribe(data => {
      window.alert('sprint started. sprint name: ' + this.backlogGroup.value.sprintName);
    });
  }
}