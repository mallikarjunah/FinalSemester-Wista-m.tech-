import { Component, OnInit, } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { IssueService } from 'src/app/shared/service/issue.service';
import { Task, SprintDetails } from 'src/app/shared/models/SprintDetails.model';
import { SprintDetailsService } from 'src/app/shared/service/sprint-details.service';
import { FormGroup, FormControl } from '@angular/forms';
import { DialogBoxComponent } from 'src/app/shared/dialog-box/dialog-box.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-current-sprint',
  templateUrl: './current-sprint.component.html',
  styleUrls: ['./current-sprint.component.scss']
})
export class CurrentSprintComponent implements OnInit {

  tasks: Task[];

  todo: Task[] = [];

  done: Task[] = [];

  inProgress: Task[] = [];

  sprintDetails: SprintDetails[] = [];
  sprintDs: SprintDetails[] = [];

  isSprintSelected = false;

  sprintFormGroup: FormGroup;

  sprintName;

  formData: string;

  constructor(private issueService: IssueService,
    private sprintService: SprintDetailsService,
    public dialog: MatDialog) {
    this.sprintFormGroup = new FormGroup({
      sprintName: new FormControl('')
    });
  }

  ngOnInit() {
    this.getOpenSprintNames();
  }

  onSearch(task) {
    console.log(task);
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '70%',
      data: task,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.formData = { id: task.id, ...result }
    });

  }


  onSelect() {
    this.sprintName = this.sprintFormGroup.value.sprintName;
    this.issueService.getIssuesBySprintNames(this.sprintFormGroup.value.sprintName).subscribe(data => {
      this.tasks = data as Task[];
      for (let i = 0; i < this.tasks.length; i++) {
        if (this.tasks[i].status === "In Progress") {
          this.inProgress.push(this.tasks[i])
        } else if (this.tasks[i].status === "To Do") {
          this.todo.push(this.tasks[i]);
        } else if (this.tasks[i].status === "Done") {
          this.done.push(this.tasks[i]);
        }
      }
    }, error => {
      console.log(error)
    });
    this.isSprintSelected = true;
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      console.log('event.previousContainer: ' + event.previousContainer)
      console.log('event.container', event.container)
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
      console.log(event.container.connectedTo);
      console.log(JSON.stringify(event.container.data[event.currentIndex]));
      // console.log('event previousContainer data' + event.previousContainer.data + ' event.container.data :' + event.container.data)
    }
  }


  getOpenSprintNames() {
    this.sprintService.getOpenSprints().subscribe(data => {
      this.sprintDs = data as SprintDetails[];
      for (let i = 0; i < this.sprintDs.length; i++) {
        if (this.sprintDs[i].sprintStatus === 'open') {
          this.sprintDetails.push(this.sprintDs[i]);
        }
      }
    })
  }

  closeSprint(sprintName) {
    console.log(sprintName + " sprint status");
    this.sprintService.openOrCloseSprint(sprintName, 'close').subscribe(data => {
      window.alert("Sprint closed '" + sprintName + "'");
    }, error => {
      console.log('error in closing sprint');
    })
  }
}
