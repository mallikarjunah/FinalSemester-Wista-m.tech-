import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { SprintDetails, UserProfile, Task } from 'src/app/shared/models/SprintDetails.model';
import { SprintDetailsService } from 'src/app/shared/service/sprint-details.service';
import { IssueService } from 'src/app/shared/service/issue.service';
import { DialogBoxComponent } from 'src/app/shared/dialog-box/dialog-box.component';
import { MatDialog, MatDatepickerInputEvent } from '@angular/material';
import { ExcelServicesService } from 'src/app/shared/service/excel-services.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  reportFormGroup: FormGroup;
  reportFormSubGroup: FormGroup;
  dateForm: FormGroup;
  isUserSelected = "";
  isSprintNameSelected = false;
  reportOptions = ['SPRINT NAME', 'TIME'];
  sprintNames: string[];
  public SystemName: string = "MF1";
  firstCopy = false;

  // data
  public lineChartData: Array<number> = [1, 8, 49];

  public labelMFL: Array<any> = [
    {
      data: this.lineChartData,
      label: this.SystemName
    }
  ];
  // labels
  public lineChartLabels: Array<any> = ["2018-01-29 10:00:00", "2018-01-29 10:27:00", "2018-01-29 10:28:00"];

  public lineChartOptions: any = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          max: 60,
          min: 0,
        }
      }],
      xAxes: [{


      }],
    },
    plugins: {
      datalabels: {
        display: true,
        align: 'top',
        anchor: 'end',
        //color: "#2756B3",
        color: "#222",

        font: {
          family: 'FontAwesome',
          size: 14
        },

      },
      deferred: false

    },

  };

  _lineChartColors: Array<any> = [{
    backgroundColor: 'red',
    borderColor: 'red',
    pointBackgroundColor: 'red',
    pointBorderColor: 'red',
    pointHoverBackgroundColor: 'red',
    pointHoverBorderColor: 'red'
  }];

  constructor(
    private sprintService: SprintDetailsService,
    private issueService: IssueService,
    public dialog: MatDialog,
    private excelService: ExcelServicesService) {
    this.reportFormGroup = new FormGroup({
      reportType: new FormControl('')
    });
    this.reportFormSubGroup = new FormGroup({
      reportSubType: new FormControl('')
    });
  }

  userDetails: UserProfile;
  ngOnInit() {
    this.userDetails = JSON.parse(sessionStorage.getItem('loginDetails'));
  }

  report() {
    if (this.reportFormGroup.value.reportType === "SPRINT NAME") {
      this.sprintService.getToDoSprint().subscribe(d => {
        this.sprintNames = d as string[];
      });
      this.isUserSelected = "sprintName";
      console.log(this.isUserSelected);
    } else if (this.reportFormGroup.value.reportType === "TIME") {
      this.dateForm = new FormGroup({
        idate: new FormControl,
        edate: new FormControl
      });
      this.isUserSelected = "time";
    }
  }

  resultDates = false;
  issues: Task[];
  resultsBasedOnDate() {
    console.log('start Date: ' + convert(this.dateForm.value.idate) + ' 00:00:00')
    console.log('end Date: ' + convert(this.dateForm.value.edate) + ' 23:59:59')
    const startDate = convert(this.dateForm.value.idate) + ' 00:00:00';
    const endDate = convert(this.dateForm.value.edate) + ' 23:59:59';
    this.issueService.getIssuesOnDate(this.userDetails.emailId, startDate, endDate).subscribe(data => {
      console.log(data)
      this.issues = data as Task[];
      this.resultDates = true;
    }, error => {
      console.log(error)
    })

  }

  sprintName;
  sprintIssues() {
    console.log('search: sprintName: ' + this.reportFormSubGroup.value.reportSubType)
    this.issueService.getIssuesBySprintNames(this.reportFormSubGroup.value.reportSubType).subscribe(res => {
      this.issues = res as Task[]
      console.log(this.issues);
      this.sprintName = this.reportFormSubGroup.value.reportSubType;
      this.isSprintNameSelected = true;
    }, error => {
      console.log(error);
    })
  }

  formData: string;
  onDisplay(task) {
    console.log(task);
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '70%',
      data: task,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.formData = { id: task.id, ...result }
      console.log('The dialog was closed', this.formData);
    });

  }
  
  exportAsXLSX(): void {
    this.excelService.exportAsExcelFile(this.issues, this.sprintName);
  }

}

function convert(str) {
  var date = new Date(str),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
  return [date.getFullYear(), mnth, day].join("-");
}