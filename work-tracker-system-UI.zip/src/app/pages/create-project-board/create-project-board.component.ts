import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Project } from 'src/app/shared/models/SprintDetails.model';
import { ProjectDetailsService } from 'src/app/shared/service/project-details.service';
import { BoardService } from 'src/app/shared/service/board.service';
import { SprintDetailsService } from 'src/app/shared/service/sprint-details.service';

@Component({
  selector: 'app-create-project-board',
  templateUrl: './create-project-board.component.html',
  styleUrls: ['./create-project-board.component.scss']
})
export class CreateProjectBoardComponent implements OnInit {
  createProjectGroup: FormGroup;
  createBoardGroup: FormGroup;
  createSprintGroup: FormGroup;
  constructor(private boardService: BoardService,
    private projectDetailsService: ProjectDetailsService,
    private sprintService: SprintDetailsService) {
    this.createProjectGroup = new FormGroup({
      projectName: new FormControl('')
    })
    this.createBoardGroup = new FormGroup({
      boardName: new FormControl(''),
      projectName: new FormControl('', [Validators.required]),
    })
    this.createSprintGroup = new FormGroup({
      sprintName: new FormControl(''),
      startDate: new FormControl(''),
      endDate: new FormControl('')
    })
  }

  projects: Project[];

  ngOnInit() {
    this.getAllProjects();
  }

  getAllProjects() {
    this.projectDetailsService.getProjects().subscribe(data => {
      this.projects = data as Project[];
      console.log('projects: ', this.projects)
    },
      error => {
        console.log('error', error)
      })
  }

  createProject(createBoardGroup) {
    this.projectDetailsService.createProject(this.createProjectGroup.value).subscribe(sucess => {
      window.alert('Project created successfully...');
    }, error => {
      window.alert('error while creating project');
    });
  }
  createBoard(createProjectGroup) {
    this.boardService.createBoard(this.createBoardGroup.value).subscribe(success => {
      window.alert('Board created successfully...');
    }, error => {
      window.alert('error while creating board');
    });
  }
  exception: exceptions;
  createSprint(createSprintGroup) {
    this.sprintService.createSprint(this.createSprintGroup.value).subscribe(x => {
      window.alert('created sprint with Name : ' + this.createSprintGroup.value.sprintName);
      this.createSprintGroup.reset();
    }, error => {
      window.alert('sprint name already present or choose end date as future date');
    })
  }
}

export interface exceptions {
  timestamp: string;
  message: string;
  details: string;
}