import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateProjectBoardComponent } from './create-project-board.component';

describe('CreateProjectBoardComponent', () => {
  let component: CreateProjectBoardComponent;
  let fixture: ComponentFixture<CreateProjectBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateProjectBoardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateProjectBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
