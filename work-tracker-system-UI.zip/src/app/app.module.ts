import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './pages/login/login.component';
import { SharedModule } from './shared/shared.module';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { DashboardMainComponent } from './pages/dashboard-main/dashboard-main.component';
import { CurrentSprintComponent } from './pages/current-sprint/current-sprint.component';
import { ReportsComponent } from './pages/reports/reports.component';
import { BacklogsComponent } from './pages/backlogs/backlogs.component';
import { ReleaseComponent } from './pages/release/release.component';
import { CreateTaskComponent } from './pages/create-task/create-task.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { RegisterComponent } from './pages/register/register.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { ChangePasswordComponent } from './pages/change-password/change-password.component';
import { SearchIssueComponent } from './pages/search-issue/search-issue.component';
import { DatePipe } from '@angular/common';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { ChartsModule } from 'ng2-charts';
import { CreateProjectBoardComponent } from './pages/create-project-board/create-project-board.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    DashboardMainComponent,
    CurrentSprintComponent,
    ReportsComponent,
    BacklogsComponent,
    ReleaseComponent,
    CreateTaskComponent,
    RegisterComponent,
    ProfileComponent,
    ChangePasswordComponent,
    SearchIssueComponent,
    CreateProjectBoardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    SharedModule,
    DragDropModule,
    FlexLayoutModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ChartsModule
  ],
  providers: [
    DatePipe,
    MatDatepickerModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
