import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { Priority, Project, Board, SprintDetails, UserProfile, Task, Comments } from '../models/SprintDetails.model';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ProjectDetailsService } from '../service/project-details.service';
import { BoardService } from '../service/board.service';
import { SprintDetailsService } from '../service/sprint-details.service';
import { GlobalService } from '../service/global.service';
import { DatePipe } from '@angular/common';
import { IssueService } from '../service/issue.service';

// export interface comment{
//   comment : string;
//   commentedBy : string;
//   commentedAt: string;
// }


@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.scss']
})
export class DialogBoxComponent implements OnInit {
  comment: Comments;
  createTaskForm: FormGroup;
  projects: Project[];
  boards: Board[];
  sprintDetails: SprintDetails[] = [];
  users: UserProfile[];

  task: Task;
  issueTypes = ['story', 'bug', 'test', 'task', 'sub task']

  priorities: Priority[] = [
    { priority: 'Low' },
    { priority: 'Minor' },
    { priority: 'Major' },
    { priority: 'Critical' },
    { priority: 'Blocker' }
  ]

  // asControl = new FormControl();
  options: string[] = [];
  statusOptions = ['To Do', 'In Progress', 'Done']
  filteredOptions: Observable<string[]>;
  userData;
  userDetails: UserProfile;
  addComment;
  id;
  constructor(
    public dialogRef: MatDialogRef<DialogBoxComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data,
    private projectDetailsService: ProjectDetailsService,
    private boardService: BoardService,
    private sprintService: SprintDetailsService,
    private globalService: GlobalService,
    private datePipe: DatePipe,
    private issueService: IssueService) {
    this.userData = data;
    this.id = data.id;

    this.userDetails = JSON.parse(sessionStorage.getItem('loginDetails'));
    console.log(this.userDetails.emailId + "details---------------" + this.userDetails)

    this.createTaskForm = this.fb.group({
      summary: [data.summary],
      sprintName: [data.sprintName],
      description: [data.description],
      projectName: [data.projectName],
      boardName: [data.boardName],
      issueType: [data.issueType],
      linkedBy: [data.linkedBy],
      status: [data.status],
      priority: [data.priority, [Validators.required]],
      assignee: [data.assignee],
      hoursSpent: [data.hoursSpent],
      estimatedHours: [data.estimatedHours],
      remainingHours: [data.remainingHours],
      createdBy: [data.createdBy],
      updatedAt: [data.updatedAt],
      createdAt: [data.createdAt],
      addComment: [''],
      comments: this.fb.array([...data.comments, {
        'comment': this.fb.control,
        'commentedAt': this.datePipe.transform(new Date(), 'dd-MM-yyyy HH:mm:ss'),
        'commentedBy': this.userDetails.emailId
      }])
    });
  }

  ngOnInit() {
    this.getOpenSprintNames();
    this.getAllProjects();
    this.getAllBoardDetails();

    this.globalService.getAllUserDetails().subscribe(data => {
      this.users = data as UserProfile[];
      for (let i = 0; i < this.users.length; i++) {
        this.options.push(this.users[i].emailId);
      }
    })

    this.filteredOptions = this.createTaskForm.get('assignee').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );

    console.log(this.userData.assignee);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  onNoClick(): void {
    this.dialogRef.close();
  }


  getAllProjects() {
    this.projectDetailsService.getProjects().subscribe(data => {
      this.projects = data as Project[];
      console.log('projects: ', this.projects)
    },
      error => {
        console.log('error', error)
      })
  }

  getAllBoardDetails() {
    this.boardService.getBoards().subscribe(data => {
      this.boards = data as Board[];
      console.log('board: ', this.boards)
    })
  }
  sprintDs: SprintDetails[];
  getOpenSprintNames() {
    this.sprintService.getOpenSprints().subscribe(data => {
      this.sprintDs = data as SprintDetails[];
      for (let i = 0; i < this.sprintDs.length; i++) {
        if (this.sprintDs[i].sprintStatus === 'open' || this.sprintDs[i].sprintStatus === 'ToDo') {
          this.sprintDetails.push(this.sprintDs[i]);
        }
      }
      console.log(this.sprintDetails)
    })
  }

  updateIssue() {
    console.log('update for id' + this.id);
    this.issueService.updateIssue(this.id, { ...this.createTaskForm.value, id: this.id }).subscribe(data => {
      console.log("success update")
    },
      error => {
        console.log("error");
      })
    console.log(this.createTaskForm.value)

  }
}
