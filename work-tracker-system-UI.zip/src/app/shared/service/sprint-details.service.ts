import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SprintDetailsService {

  constructor(private http: HttpClient) { }

  getOpenSprints() {
    return this.http.get('http://localhost:8200/sprint/sprints/names');
  }

  getToDoSprint() {
    return this.http.get('http://localhost:8200/sprint/sprint/todo');
  }

  openOrCloseSprint(sprintName, status) {
    console.log('sprintName: ' + sprintName + ' status: ' + status)
    return this.http.put('http://localhost:8200/sprint/sprint/startOrEndSprint/' + sprintName + '?status=' + status, null)
  }

  createSprint(sprint) {
    return this.http.post('http://localhost:8200/sprint/sprints', sprint);
  }
}
