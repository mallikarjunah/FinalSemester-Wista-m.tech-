import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  isLoginPage = false;
  isProfilePage = false;

  constructor(private http: HttpClient, private router: Router) { }

  login(user: any): Observable<any> {
    const options = { responseType: 'text' as 'json' };
    return this.http.get("http://localhost:8200/sprint/login?username=" + user.username + "&password=" + user.password);
  }


  getAllUserDetails() {
    return this.http.get('http://localhost:8200/sprint/users');
  }

  register(user: any): Observable<any> {
    return this.http.post('http://localhost:8200/sprint/users', user);
  }

  logout() {
    sessionStorage.removeItem('loginDetails');
    this.router.navigate(['/login']);
  }

  changePassword(userId, password) {
    return this.http.put('http://localhost:8200/sprint/changepassword?id=' + userId + '&password=' + password, null)
  }

  updateProfile(id, user) {
    return this.http.put('http://localhost:8200/sprint/users/update?id=' + id, user);
  }
}
