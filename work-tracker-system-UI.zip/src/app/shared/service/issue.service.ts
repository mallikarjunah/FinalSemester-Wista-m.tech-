import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  constructor(private http: HttpClient) { }

  getIssues(emailId?): Observable<any> {
    return this.http.get('http://localhost:8200/sprint/issues/assignee/' + emailId);
  }

  createTask(issue: any): Observable<any> {
    return this.http.post('http://localhost:8200/sprint/issues', issue);
  }

  getIssuesByUserId(assignee) {

  }

  getIssuesOnDate(id, startDate, endDate) {
    return this.http.get('http://localhost:8200/sprint/onDate?emailId=' + id + '&startDate=' + startDate + '&endDate=' + endDate)
  }
  getIssuesBySprintNames(name) {
    return this.http.get('http://localhost:8200/sprint/issues/' + name + '/sprint');
  }

  search(input?) {
    return this.http.get('http://localhost:8200/sprint/issues/' + input + '/search')
  }

  updateIssue(id, issue: any): Observable<any> {
    return this.http.put('http://localhost:8200/sprint/issues/update?id=' + id, issue);
  }

  backlogs() {
    return this.http.get('http://localhost:8200/sprint/backlogs');
  }
}
