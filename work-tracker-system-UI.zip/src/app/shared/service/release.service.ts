import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReleaseService {

  constructor(private http: HttpClient) { }

  createRelease(release) {
    return this.http.post('http://localhost:8200/sprint/release', release);
  }

  getAllRelease() {
    return this.http.get('http://localhost:8200/sprint/release/list');
  }

  getReleaseDetailsByProjectName(projectName) {
    return this.http.get('http://localhost:8200/sprint/release/project/' + projectName)
  }
}
