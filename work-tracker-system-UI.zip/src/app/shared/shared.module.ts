import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './material/material.module';
import { AuthGuardService } from './service/auth-guard.service';
import { GlobalService } from './service/global.service';
import { HeaderComponent } from './header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
import { RouterModule } from '@angular/router';

@NgModule({
    declarations: [
        HeaderComponent,
        DialogBoxComponent
    ],
    imports: [
        CommonModule, 
        MaterialModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule
    ],
    exports:[
        MaterialModule,
        HeaderComponent,
        DialogBoxComponent
    ],
    providers: [
        AuthGuardService,
        GlobalService
    ],
    entryComponents: [
        DialogBoxComponent
    ]
})
export class SharedModule {

}