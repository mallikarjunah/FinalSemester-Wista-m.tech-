import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { GlobalService } from '../service/global.service';
import { UserProfile, Task } from '../models/SprintDetails.model';
import { IssueService } from '../service/issue.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  issues: Task[];

  title = 'angular-material-login-template';
  
  emailId;
  userProfile: UserProfile;
  isLoginPage = false;
  isProfilePage = false;
  toggleSideNav = true;
  @Output() openCloseSideNav = new EventEmitter<boolean>();
  constructor(private globalService: GlobalService, private issueService: IssueService) { }



  ngOnInit() {
    this.isLoginPage = this.globalService.isLoginPage;
    this.isProfilePage = this.globalService.isProfilePage;
    this.openCloseSideNav.emit(this.toggleSideNav);
    this.userProfile = JSON.parse(sessionStorage.getItem('loginDetails'));
  }

  openSidenav() {
    this.toggleSideNav = !this.toggleSideNav;
    this.openCloseSideNav.emit(this.toggleSideNav);
  }

  logout() {
    this.globalService.logout();
  }

  searchByInput(input) {
    this.issueService.search(input).subscribe(data => {
      console.log(data)
    },
      error => {
        console.log(error);
      })
  }

}
