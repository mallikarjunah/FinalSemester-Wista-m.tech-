export interface SprintDetails {
  id: Number;
  sprintName: string;
  startDate: string;
  endDdate: string;
  projectName: string;
  boardName: string;
  sprintStatus: string;
}

export interface SprintTasks {
  userName: String;
  userId: String;
  tasks: Task[];
}

export interface Comments {
  comment: String;
  commentedAt: String;
  commentedBy: String;
}


export interface Task {
  assignee: string,
  boardName: String,
  comments: Comments[],
  createdAt: String,
  createdBy: String,
  description: String,
  estimatedHours: Number,
  hoursSpent: Number,
  id: Number,
  issueType: String,
  linkedBy: String,
  priority: String,
  projectName: String,
  remainingHours: Number,
  status: String,
  summary: String,
  updatedAt: String
}

export interface Project {
  id: Number;
  projectName: string;
}
export interface Board {
  id: Number;
  projectName: string;
  boardName: string;
}

export interface Priority {
  priority: string;
}

export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}

export interface UserProfile {
  userId: Number;
  projectName: string;
  userName: string;
  emailId: string;
  password: string;
  updatedAt: string;
  firstName: string;
  lastName: string;
}

export class Release{
  id : Number;
  name : string;
  projectName : string;
  releaseDate : string;
  version: number;
  description : string;
}