import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    MatAutocompleteModule, MatCheckboxModule,
    MatDatepickerModule, MatFormFieldModule,
    MatInputModule, MatRadioModule,
    MatSelectModule, MatSliderModule,
    MatSlideToggleModule, MatMenuModule,
    MatSidenavModule, MatToolbarModule,
    MatCardModule, MatDividerModule,
    MatExpansionModule, MatGridListModule,
    MatListModule, MatStepperModule,
    MatTabsModule, MatTreeModule,
    MatButtonModule, MatButtonToggleModule,
    MatBadgeModule, MatChipsModule,
    MatIconModule, MatProgressSpinnerModule,
    MatProgressBarModule, MatRippleModule,
    MatBottomSheetModule, MatDialogModule,
    MatSnackBarModule, MatTooltipModule,
    MatPaginatorModule, MatSortModule,
    MatTableModule
  } from '@angular/material';
  import { FlexLayoutModule, BREAKPOINT } from '@angular/flex-layout';

@NgModule({
    declarations: [],
    imports: [
        CommonModule
    ],
    exports :[
        MatAutocompleteModule, MatCheckboxModule,
    MatDatepickerModule, MatFormFieldModule,
    MatInputModule, MatRadioModule,
    MatSelectModule, MatSliderModule,
    MatSlideToggleModule, MatMenuModule,
    MatSidenavModule, MatToolbarModule,
    MatCardModule, MatDividerModule,
    MatExpansionModule, MatGridListModule,
    MatListModule, MatStepperModule,
    MatTabsModule, MatTreeModule,
    MatButtonModule, MatButtonToggleModule,
    MatBadgeModule, MatChipsModule,
    MatIconModule, MatProgressSpinnerModule,
    MatProgressBarModule, MatRippleModule,
    MatBottomSheetModule, MatDialogModule,
    MatSnackBarModule, MatTooltipModule,
    MatPaginatorModule, MatSortModule,
    MatTableModule, FlexLayoutModule
    ]
})
export class MaterialModule { }